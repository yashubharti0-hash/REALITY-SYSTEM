package com.realitysystem

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale

private val Navy = Color(0xFF071321)
private val Panel = Color(0xFF10263B)
private val Cyan = Color(0xFF53DFFF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { RealityApp(this) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            ready = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setSpeechRate(0.95f)
        }
    }

    fun speak(message: String) {
        if (ready) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "reality_voice")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun RealityApp(activity: MainActivity) {
    val context = activity
    val prefs = remember { context.getSharedPreferences("reality", Context.MODE_PRIVATE) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var input by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("System online. Aaj ka mission shuru karein?") }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            input = spoken
            reply = localCommand(context, spoken)
            activity.speak(reply)
        }
    }
    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchSpeech(speechLauncher) else reply = "Microphone permission allow karein."
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("REALITY SYSTEM", style = MaterialTheme.typography.headlineMedium, color = Cyan)
                    Text("PERSONAL AI • PLAYER DASHBOARD", color = Color.LightGray)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("PLAYER STATUS", color = Cyan)
                            Text("LEVEL ${xp / 100 + 1}", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                            Text("$xp XP • $completed quests completed", color = Color.LightGray)
                            LinearProgressIndicator(
                                progress = { (xp % 100) / 100f },
                                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                            )
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("SYSTEM ASSISTANT", color = Cyan)
                            Text(reply, color = Color.White, modifier = Modifier.padding(vertical = 10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = {
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                                        == PackageManager.PERMISSION_GRANTED) launchSpeech(speechLauncher)
                                    else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                                }) {
                                    Icon(Icons.Default.Mic, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Speak")
                                }
                                Spacer(Modifier.width(8.dp))
                                OutlinedButton(onClick = { activity.speak(reply) }) { Text("Play voice") }
                            }
                            OutlinedTextField(
                                value = input, onValueChange = { input = it },
                                label = { Text("Type a command") }, modifier = Modifier.fillMaxWidth()
                            )
                            Button(onClick = {
                                reply = localCommand(context, input)
                                activity.speak(reply)
                            }, modifier = Modifier.padding(top = 8.dp)) { Text("Run command") }
                        }
                    }
                }
                item { Text("DAILY QUESTS", color = Cyan, style = MaterialTheme.typography.titleLarge) }
                item {
                    QuestCard("Morning workout", "10–20 min beginner strength session") {
                        xp += 20; completed++
                        prefs.edit().putInt("xp", xp).putInt("completed", completed).apply()
                        reply = "Quest complete! 20 XP earned."; activity.speak(reply)
                    }
                }
                item {
                    QuestCard("Study mission", "Study for 45 minutes for your target exam") {
                        xp += 25; completed++
                        prefs.edit().putInt("xp", xp).putInt("completed", completed).apply()
                        reply = "Study mission complete! 25 XP earned."; activity.speak(reply)
                    }
                }
                item {
                    QuestCard("Daily discipline", "Plan tomorrow and review today's progress") {
                        xp += 10; completed++
                        prefs.edit().putInt("xp", xp).putInt("completed", completed).apply()
                        reply = "Daily discipline quest complete! 10 XP earned."; activity.speak(reply)
                    }
                }
                item {
                    Text("TOOLS", color = Cyan, style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scheduleDailyAlarm(context, 6, 0)
                            reply = "6 AM alarm schedule karne ki request bheji."
                            activity.speak(reply)
                        }) { Text("Set 6 AM alarm") }
                        OutlinedButton(onClick = {
                            context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                        }) { Text("Phone settings") }
                    }
                }
                item {
                    Text("ONLINE SERVICES", color = Cyan)
                    Text(
                        "Cloud AI, live weather aur news abhi connected nahi hain. Inke liye secure backend configuration agle development step mein add hogi.",
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}

@Composable
fun QuestCard(title: String, detail: String, onDone: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(detail, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onDone) { Text("Complete") }
        }
    }
}

private fun launchSpeech(launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "REALITY SYSTEM ko command dein")
    }
    launcher.launch(intent)
}

fun localCommand(context: Context, command: String): String {
    val c = command.lowercase(Locale.ROOT)
    return when {
        c.contains("alarm") || c.contains("wake") -> {
            scheduleDailyAlarm(context, 6, 0); "Aapka 6 AM daily alarm schedule karne ki request bheji."
        }
        c.contains("setting") -> {
            context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            "Phone settings khol raha hoon."
        }
        c.contains("fitness") || c.contains("workout") ->
            "Aaj beginner workout: 10 squats, 8 wall push-ups aur 15 minute walk. Pain ho to stop karein."
        c.contains("study") || c.contains("padh") ->
            "Study mission: 25 minute Maths, 25 minute Reasoning aur 20 minute General Knowledge."
        c.isBlank() -> "Command type ya speak karein."
        else -> "Main abhi offline starter mode mein hoon. Is command ke liye online AI backend connect karna hoga."
    }
}

fun scheduleDailyAlarm(context: Context, hour: Int, minute: Int) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, 600, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    if (android.os.Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
        val settings = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(settings)
        return
    }
    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
}
