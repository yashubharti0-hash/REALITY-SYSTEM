# REALITY SYSTEM — Android starter

Android Studio project using Kotlin and Jetpack Compose.

## Included
- Dark dashboard
- Android speech recognition (Hindi India request)
- Android TextToSpeech (voice depends on installed Hindi voices; choose a female voice in Android TTS settings if available)
- Basic offline voice/text commands
- Local daily quests and XP counter
- 6 AM alarm scheduling and notification receiver

## Not yet included
Cloud AI chat, live weather/news APIs, and broad phone automation are not connected in this starter. Android restricts silent control of other apps and settings. A secure backend is required for AI provider API keys; never embed private keys in the APK.

## Requirements
- Android Studio / compatible Android IDE
- JDK 17
- Android SDK 35
- Android 8.0 or newer device

## Build
Open this folder as a Gradle project, sync, then build `:app:assembleDebug`.
The APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

For GitHub Actions, upload this ZIP to your repository root and add the workflow described in the setup instructions. Extract the ZIP in the workflow before running Gradle.

## Permissions
Grant microphone and notification permissions when needed. Exact alarms may require enabling the app under Android's Alarms & reminders special access. Battery optimizations vary by manufacturer.
